package scenario;
//кнопочки
public interface IScenario {
    String getName();
}


