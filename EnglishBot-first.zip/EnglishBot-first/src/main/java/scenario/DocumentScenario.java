package scenario;

public class DocumentScenario implements IScenario{
    @Override
    public String getName() {
        return "Документ\uD83D\uDCDD";
    }
}
