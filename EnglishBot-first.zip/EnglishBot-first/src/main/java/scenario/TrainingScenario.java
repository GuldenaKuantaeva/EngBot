package scenario;

public class TrainingScenario implements IScenario{
    @Override
    public String getName() {
        return "Тренировка\uD83C\uDFC6";
    }
}
