package scenario.translate;

public interface ILanguage {
    String getLocale();
}
