package scenario.translate;

public class RussianLanguage implements ILanguage{
    @Override
    public String getLocale() {
        return "ru";
    }
}
