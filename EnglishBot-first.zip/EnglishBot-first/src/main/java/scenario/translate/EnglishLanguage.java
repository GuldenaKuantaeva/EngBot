package scenario.translate;

public class EnglishLanguage implements ILanguage{
    @Override
    public String getLocale() {
        return "en";
    }
}
